=== News Ticker ===
Contributors: hossam, gpt5-thinking
Requires at least: 6.3
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
Tags: news, ticker, marquee, typewriter, rtl, wpbakery

A modern, accessible, RTL-friendly news ticker with Marquee and Typewriter modes. Block + Shortcode + WPBakery.
- Top-level admin menu
- Sticky/Urgent options
- Guest Transient cache
- Pause on hover/focus
- Lazy prefetch of next link
